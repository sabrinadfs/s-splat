package entry;

public interface Entry {
	
	public String toString();
	public boolean equals(Object o);
	public Entry clone();

}
