#!/bin/bash

echo "=================ZIPME================="
./ssplat zipme false 1 false

echo "=================GPL================="
./ssplat gpl false 1 false

echo "=================EMAIL================="
./ssplat email false 1 false

echo "=================SUDOKU================="
./ssplat sudoku false 1 false

echo "=================JTOPAS================="
./ssplat jtopas false 1 false

echo "=================COMPANIES================="
./ssplat companies false 1 false

echo "=================NOTEPAD================="
./ssplat notepad false 1 false

echo "=================DESKTOPSEARCHER================="
./ssplat desktopsearcher false 1 false
