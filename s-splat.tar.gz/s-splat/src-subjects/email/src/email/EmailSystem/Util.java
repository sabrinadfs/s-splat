package email.EmailSystem; 

public  class  Util {
	

	public static void prompt(String msg) {
		 System.out.println(msg);
	}

	

	public static void prompt(int msg) {
		prompt(String.valueOf(msg));
	}


}
