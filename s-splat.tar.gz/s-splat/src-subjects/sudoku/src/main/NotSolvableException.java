package main;

/** 
 * 
 * 
 */ 
public class NotSolvableException extends Exception { 
 
    /** 
     * 
     */ 
    public NotSolvableException() { 
//    	if(SudokuTEST.SINGLETON.get_BASE___()){ }
    } 
 
    /** 
     * @param msg 
     *           Error message 
     */ 
    public NotSolvableException(String msg) { 
        super(msg); 
//        if(SudokuTEST.SINGLETON.get_BASE___()){ }
    } 
 
} 
