package main;
public interface Solver {//SOLVER

    public boolean trySolve(Board board);//SOLVER

}//SOLVER
