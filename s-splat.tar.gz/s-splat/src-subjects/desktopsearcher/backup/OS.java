

public class OS {
	public static String getPathSeparator()
	{
		return "\\\\";
	}
	
	public static char getPathSeparatorChar()
	{
		return '\\';
	}
}