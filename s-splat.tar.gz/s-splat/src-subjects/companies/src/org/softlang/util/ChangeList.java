package org.softlang.util;






/**
 * Represent changes to observable lists
 */
public abstract class ChangeList {
	public Object element;
}
