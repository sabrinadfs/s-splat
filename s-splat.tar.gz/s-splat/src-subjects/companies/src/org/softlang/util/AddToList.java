package org.softlang.util;






public class AddToList extends ChangeList {
	public AddToList(Object o) { this.element = o; }
}
