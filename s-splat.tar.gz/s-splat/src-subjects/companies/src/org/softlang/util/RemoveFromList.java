package org.softlang.util;






public class RemoveFromList extends ChangeList {
	public RemoveFromList(Object o) { this.element = o; }
}
