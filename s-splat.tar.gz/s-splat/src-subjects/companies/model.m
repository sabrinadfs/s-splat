//hared
Companies: TREE_STRUCTURE___ [LOGGING___] [Cut] [GUI___] [PRECEDENCE___] [Total] [ACCESS_CONTROL___] :: _Companies;
Cut: CUT_WHATEVER___ | CUT_NO_DEPARTMENT___ | CUT_NO_MANAGER___;
Total: TOTAL_WALKER___ | TOTAL_REDUCER___;