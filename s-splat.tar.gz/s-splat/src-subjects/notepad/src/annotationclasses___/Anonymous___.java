package annotationclasses___;

public @interface Anonymous___ {
	String value();
}
