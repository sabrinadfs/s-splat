package annotationclasses___;
public @interface Feature___{
	String value();
}