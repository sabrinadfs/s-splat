package tests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
    FirstSuit.class, 
    GZIPtest.class, 
    LitleFeatures.class,
    Addler32CheckSumTest.class, 
    CompressAdlerCSTests.class,
    DerivGZIPEXTRTest.class, 
    DerivGZIPEXTRTest2.class, 
    ExtractTest.class,
    Example_Paulo.class,  
    Example_Paulo2.class 
    })
public class TestAll extends ZipMeTest {
}