#!/bin/bash

# function gen() {
#     SUBJECT="$1"
#     ASPECTR="$2"
#     R --vanilla < script.r --args "${SUBJECT}" "${ASPECTR}"
#     mv Rplots.pdf ${SUBJECT}.pdf
# }

# gen "email" "60"
# gen "gpl" "120"
# gen "jtopas" "3"
# gen "sudoku" "12"
# gen "zipme" "3"

R --vanilla < script.r


