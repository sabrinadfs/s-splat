I#!/usr/bin/env Rscript

# please, install these packages first if you see an error
# install.packages("dplyr")
# install.packages("ggplot2")


library(dplyr)
library(ggplot2)
library(ggrepel)
library(cowplot)
library(gridExtra)
library(grid)
library(lattice)
library(rPref)
library(igraph) 

set.seed(42)

# 6x3 inches
pdf("grid.pdf", width=7, height=12)
# 10x6 cm
#pdf("grid.pdf", width=10/2.54, height=6/2.54)


genplot <- function(filename) {
  # data
  mydata <- read.table(filename, header=TRUE)

#  sky1 <- psel(mtcars, high(mpg) * high(hp))
  skyline <- psel(mydata, high(AVG_NUM_FAILURES) * low(AVG_SAMPLE))

  # create text grob to name the plot
  grob <- grobTree(textGrob(substr(filename, 1, nchar(filename)-4), x=0.35,  y=0.97, hjust=0, gp=gpar(col="black", fontsize=13, fontface="bold.italic")))
  ##     geom_text(data = NULL, x = 5, y = 30, label = substr(filename, 1, nchar(filename)-4))  
  
  p1 <- ggplot(mydata, aes(x = AVG_SAMPLE, y = AVG_NUM_FAILURES)) +
     geom_point(color='red', shape=1) + 
     annotation_custom(grob) +
     ## repel labels (so that you can see them all)
     geom_text_repel(
      data=mydata,
      aes(label=TECHNIQUE),
      size = 3,
      box.padding = unit(0.4, 'lines'),
      point.padding = unit(1.6, 'lines'),
      segment.color = '#555555',
      segment.size = 0.5,
      arrow = arrow(length = unit(0.02, 'npc')),
      force = 1,
      max.iter = 2e5,
     ) +
     ## show skyline (paretto frontier)
     geom_point(data=skyline, size=2) +
     ## beautify axis
     theme(axis.title.x=element_blank(), axis.title.y=element_blank(), axis.text.x = element_text(size=16), axis.text.y = element_text(size=16)) 
  return(p1)
}

p1 <- genplot("companies.txt")
p2 <- genplot("desktop.txt")
p3 <- genplot("email.txt")
p4 <- genplot("gpl.txt")
p5 <- genplot("jtopas.txt")
p6 <- genplot("notepad.txt")
p7 <- genplot("sudoku.txt")
p8 <- genplot("zipme.txt")

## effectively generate the plot
grid.arrange(p1, p2, p3, p4, p5, p6, p7, p8, ncol=2)
