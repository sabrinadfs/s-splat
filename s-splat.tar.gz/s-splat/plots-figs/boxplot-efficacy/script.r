#!/usr/bin/env Rscript

library(ggplot2)
library(cowplot)

set.seed(42)

pdf("all-failures.pdf", width=7, height=2)

mydata <- read.table("all-failures.txt", header=FALSE)

p <- ggplot(mydata, aes(x=factor(mydata$V1,c("med","ran","oe","pw","od","splat")), y=mydata$V2), position = position_dodge(10))

p + geom_boxplot() + geom_jitter() + theme(axis.title.x=element_blank(), axis.title.y=element_blank(), axis.text.x = element_text(size=30), axis.text.y = element_text(size=18))
