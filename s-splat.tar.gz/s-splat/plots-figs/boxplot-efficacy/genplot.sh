#!/bin/bash

## preparing data (group data for technique) to show in boxplots



for z in companies desktop email gpl jtopas notepad sudoku zipme
do
    for x in med oe pw od splat random
    do
        res=$(grep $x ../samplesize-versus-numfailures/$z.txt | awk '{print $1}')
        if [[ -z "${res// }" ]];
        then
            # did not run technique on this data!
            #res="NA"
            continue
        fi

        if [ "${x}" = "random" ];
        then
            x="ran"
        fi
        printf "%s %s\n" "$x $res "
    done
done  > "all-failures.txt"

R --vanilla < script.r 

