#!/bin/bash

## preparing data (group data for technique) to show in boxplots


(
    for z in companies desktop email gpl jtopas notepad sudoku zipme
    do
        for x in med oe pw od 
        do
            res=$(grep $x ../samplesize-versus-numfailures/$z.txt | awk '{print $2}')
            if [[ -z "${res// }" ]];
            then
                # did not run technique on this data!
                res="NA"
            fi

            if [ "${x}" = "random" ];
            then
                x="ran"
            fi
            
            printf "%s %s\n" "$x $res "
        done
    done
) > "all-but-splat-random.txt"


(
    for z in companies desktop email gpl jtopas notepad sudoku zipme
    do
        for x in splat random
        do
            res=$(grep $x ../samplesize-versus-numfailures/$z.txt | awk '{print $2}')
            if [[ -z "${res// }" ]];
            then
                # did not run technique on this data!
                res="NA"
            fi

            if [ "${x}" = "random" ];
            then
                x="ran"
            fi
            
            printf "%s %s\n" "$x $res "
        done
    done
) > "splat-random.txt"

R --vanilla < script_all_but.r --args "all-but-splat-random" 7
R --vanilla < script.r --args "splat-random" 5

