#!/usr/bin/env Rscript

library(ggplot2)
library(cowplot)
set.seed(42)

#options(echo=TRUE) # if you want see commands in output file
args <- commandArgs(trailingOnly = TRUE)

name <- args[1]

pdf(paste(name,".pdf",sep=""), width=args[2], height=3)

mydata <- read.table(paste(name,".txt",sep=""), header=FALSE)

p <- ggplot(mydata, aes(x=factor(mydata$V1,c("med","oe","pw","od")), y=mydata$V2))

p + geom_boxplot() + geom_jitter() + theme(axis.title.x=element_blank(), axis.title.y=element_blank(), axis.text.x = element_text(size=35), axis.text.y = element_text(size=25))
